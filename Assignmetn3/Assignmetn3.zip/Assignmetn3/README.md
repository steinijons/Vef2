# How to use template

## Prerequisites
You need to have NodeJS installed in order to use this.

## Getting started
Run in the Terminal

```
npm install

npm start
```

When you have run npm start, the browser opens up on localhost:9000 and every time you change your code within the /src folder the browser refreshes and shows the latest updates
